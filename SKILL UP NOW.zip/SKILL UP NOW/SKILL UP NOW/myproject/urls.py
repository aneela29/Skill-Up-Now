"""
URL configuration for myproject project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from myapp import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.view_index, name='index'),
    path('about.html/', views.view_about, name='about'),
    path('mypage.html/', views.view_mypage, name='mypage'),
    path('gameDeb.html/', views.view_gameDeb, name='gameDeb'),
    path('marketing.html/', views.view_marketing, name='marketing'),
    path('graphic.html/', views.view_graphic , name='graphic'),
    path('testimonial.html/', views.view_testimonial , name='testimonial'),
    path('contact.html/', views.view_contact, name='contact'),
    path('signup.html/', views.view_signup  , name='signup'),
    path('signin.html/', views.view_signin , name='signin'),
    path('logout/', views.view_logout, name='logout'),
    path('course.html/', views.view_course, name='course'),
    path('cart/', views.view_cart, name='cart'),
    path('book-now/', views.book_now, name='book_now'),
    path('booking.html/', views.view_booking, name='booking'),

]+ static('/img/', document_root=settings.MEDIA_ROOT)




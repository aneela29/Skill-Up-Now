from django.shortcuts import render, redirect
from myapp.models import CustomUser
from myapp.backends import EmailBackend
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout
from myapp.models import Course, Booking

# Create your views here.
def view_index(request):
    # Get the count of bookings for the logged-in user with status=1
    if request.user.is_authenticated:
        cart_item_count = Booking.objects.filter(user=request.user, status=1).count()
    else:
        cart_item_count = 0
    
    # Get all packages
    courses = Course.objects.all()
    for course in courses:
        # Ensure image_path is not None before calling startswith()
        if course.image_path:
            course.is_full_path = course.image_path.startswith('img/')
        else:
            course.is_full_path = False  # or any default value you prefer

    # Render the template with the packages and cart_item_count
    return render(request, 'index.html', {'courses': courses, 'cart_item_count': cart_item_count})

def view_about(request):
    # Initialize the cart item count to 0
    cart_item_count = 0
    
    # Check if the user is authenticated
    if request.user.is_authenticated:
        # Get the number of bookings with status=1 for the authenticated user
        cart_item_count = Booking.objects.filter(user=request.user, status=1).count()

    # Render the 'package.html' template and pass the packages and cart item count
    return render(request, 'about.html', { 'cart_item_count': cart_item_count})

def view_contact(request):
    # Initialize the cart item count to 0
    cart_item_count = 0
    
    # Check if the user is authenticated
    if request.user.is_authenticated:
        # Get the number of bookings with status=1 for the authenticated user
        cart_item_count = Booking.objects.filter(user=request.user, status=1).count()

    # Render the 'package.html' template and pass the packages and cart item count
    return render(request, 'contact.html', { 'cart_item_count': cart_item_count})


def view_testimonial(request):
     # Initialize the cart item count to 0
    cart_item_count = 0
    
    # Check if the user is authenticated
    if request.user.is_authenticated:
        # Get the number of bookings with status=1 for the authenticated user
        cart_item_count = Booking.objects.filter(user=request.user, status=1).count()

    # Render the 'package.html' template and pass the packages and cart item count
    return render(request, 'testimonial.html', { 'cart_item_count': cart_item_count})


def view_signin(request):
    if request.method=='POST':
        email=request.POST.get('email')  
        password=request.POST.get('password')
        user=EmailBackend.authenticate(request, email=email, password=password)
        if user is not None:
            login(request, user)
            return redirect('mypage')
        else:
            return render(request, 'error.html',  {'error_message': 'Invalid email or password'}) 
    return render(request, 'signin.html')


def view_gameDeb(request):
    # Initialize the cart item count to 0
    cart_item_count = 0
    
    # Check if the user is authenticated
    if request.user.is_authenticated:
        # Get the number of bookings with status=1 for the authenticated user
        cart_item_count = Booking.objects.filter(user=request.user, status=1).count()

    # Render the 'package.html' template and pass the packages and cart item count
    return render(request, 'gameDeb.html', { 'cart_item_count': cart_item_count})

@login_required
def view_mypage(request):
    # Retrieve user information
    user = request.user
    name = user.name 
    email = user.email

    # Initialize the cart item count to 0
    cart_item_count = 0
    
    # Check if the user is authenticated
    if request.user.is_authenticated:
        # Get the number of bookings with status=1 for the authenticated user
        cart_item_count = Booking.objects.filter(user=request.user, status=1).count()

    # Pass the user data and cart item count in the context
    context = {
        'user': user,
        'name': name,
        'email': email,
        'cart_item_count': cart_item_count  # Add cart item count to context
    }

    return render(request, 'mypage.html', context)

def view_signup(request):
    if request.method=='POST':
        name=request.POST.get('name')
        email=request.POST.get('email')
        number=request.POST.get('number')
        password=request.POST.get('password')
        user=CustomUser.objects.create_user(name = name, email = email, number = number, password = password)
        user.save()   
    return render(request, 'signup.html')
       
def view_marketing(request):
 # Initialize the cart item count to 0
    cart_item_count = 0
    
    # Check if the user is authenticated
    if request.user.is_authenticated:
        # Get the number of bookings with status=1 for the authenticated user
        cart_item_count = Booking.objects.filter(user=request.user, status=1).count()

    # Render the 'package.html' template and pass the packages and cart item count
    return render(request, 'marketing.html', { 'cart_item_count': cart_item_count})
   

def view_graphic(request):
    # Initialize the cart item count to 0
    cart_item_count = 0
    
    # Check if the user is authenticated
    if request.user.is_authenticated:
        # Get the number of bookings with status=1 for the authenticated user
        cart_item_count = Booking.objects.filter(user=request.user, status=1).count()

    # Render the 'package.html' template and pass the packages and cart item count
    return render(request, 'graphic.html', { 'cart_item_count': cart_item_count})


def view_logout(request):
    logout(request)
    return redirect('signup')  
    
def view_course(request):
    # Get all packages
    courses = Course.objects.all()
    for course in courses:
        # Ensure image_path is not None before calling startswith()
        if course.image_path:
            course.is_full_path = course.image_path.startswith('img/')
        else:
            course.is_full_path = False  # or any default value you prefer
    # Initialize the cart item count to 0
    cart_item_count = 0
    
    # Check if the user is authenticated
    if request.user.is_authenticated:
        # Get the number of bookings with status=1 for the authenticated user
        cart_item_count = Booking.objects.filter(user=request.user, status=1).count()

    # Render the 'package.html' template and pass the packages and cart item count
    return render(request, 'course.html', {'courses': courses, 'cart_item_count': cart_item_count})

def view_booking(request):
    # Fetch all packages from the database
    courses = Course.objects.all()
    
    # Initialize the cart item count to 0
    cart_item_count = 0
    
    # Check if the user is authenticated
    if request.user.is_authenticated:
        # Get the number of bookings with status=1 for the authenticated user
        cart_item_count = Booking.objects.filter(user=request.user, status=1).count()
        
    # Render the 'package.html' template and pass athe packages and cart item count
    return render(request, 'booking.html', {'courses': courses, 'crt_item_count': cart_item_count})

@login_required
def book_now(request):  
    if request.method == 'POST':  
        # Get data from the form  
        start_date = request.POST.get('date')  # Date field from the form  
        student_name = request.POST.get('student_name')  # Student name field  
        course_id = request.POST.get('course')  # Get the course ID from the form  

        # Try to fetch the course, and handle DoesNotExist  
        try:  
            course = Course.objects.get(id=course_id)  
        except Course.DoesNotExist:  
            return render(request, 'error.html', {'message': 'Course does not exist.'})  # Handle the error as appropriate  
            
        # Create a new booking with status=1 (indicating it's in the cart)  
        Booking.objects.create(  
            user=request.user,  
            course=course,  
            start_date=start_date,  
            student_name=student_name,  
            status=1  # Status=1 indicates the booking is in the cart  
        )  

        # Redirect to the cart page or another page  
        return redirect('cart')  # Adjust the URL name as per your app  
    
    # Redirect to the packages page if accessed without POST data  
    return redirect('course')  

def view_cart(request):
    # Initialize the cart item count to 0
    cart_item_count = 0
    cart_items = []  # Initialize an empty list for cart items

    # Check if the user is authenticated
    if request.user.is_authenticated:
        # Get the cart items for the authenticated user (with status=1 for active items)
        cart_items = Booking.objects.filter(user=request.user, status=1)
        cart_item_count = cart_items.count()  # Count the number of cart items
    
    # Render the 'cart.html' template and pass the cart items and cart item count
    return render(request, 'cart.html', {'cart_items': cart_items, 'cart_item_count': cart_item_count})
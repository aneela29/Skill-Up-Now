from django.contrib.auth.models import AbstractBaseUser, BaseUserManager
from django.core.validators import validate_email
from django.core.exceptions import ValidationError
from django.db import models
from django.utils import timezone

class CustomUserManager(BaseUserManager):
    def create_user(self, name, email, number, password=None, user_type='user'):
        if not email:
            raise ValueError('The Email field must be set')
        email = self.normalize_email(email)
        user = self.model(name=name, email=email, number=number, type=user_type)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, name, email, number, password=None):
        # If you don't need any 'superuser' functionality, this could be the same as `create_user`
        return self.create_user(name, email, number, password, user_type='admin')
        

class CustomUser(AbstractBaseUser):
    name = models.CharField(max_length=150)
    email = models.EmailField(unique=True)
    number = models.CharField(max_length=15, unique=True)
    type = models.CharField(max_length=50, default='user')  # Define specific choices if needed
    is_active = models.BooleanField(default=True)

    objects = CustomUserManager()

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['name', 'number']

    class Meta:
        db_table = 'users'

    def __str__(self):
        return self.email

class Course(models.Model):
    instructor = models.CharField(max_length=255)
    duration = models.PositiveIntegerField(help_text="Duration in days")
    number_of_student = models.PositiveIntegerField()
    price = models.DecimalField(max_digits=10, decimal_places=2)
    course_name = models.TextField(blank=True, null=True)
    image_path = models.CharField(max_length=255, null=True, blank=True)  # Add image_path field

    def __str__(self):
        return f"{self.course_name} - {self.instructor} ({self.duration} days, {self.number_of_student} students)"
    
    class Meta:
        db_table = 'courses'
 

class Booking(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)  
    course = models.ForeignKey(Course, on_delete=models.CASCADE)  
    start_date = models.DateField(null=True, blank=True)
    status = models.IntegerField(default=1)  # Optional field for cart status
    student_name = models.CharField(max_length=100, blank=True, null=True)  
    created_at = models.DateTimeField(auto_now_add=True)  

    def __str__(self):  
        return f"{self.student_name} - {self.course.course_name}"
    class Meta:
        db_table = 'bookings'
